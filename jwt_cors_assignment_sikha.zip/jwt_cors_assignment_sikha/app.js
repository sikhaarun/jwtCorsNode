let express= require('express');
let fs=require('fs');
let jwt = require('jsonwebtoken');
let cors = require('cors');
//cors article
//https://expressjs.com/en/resources/middleware/cors.html


let app=express();


let searchUser = (obj)=>{
    let users= JSON.parse(fs.readFileSync(__dirname+'/users.json','utf8'));
    let userExist=users.filter((item)=>
    {
        return item.name == obj.username && item.password == obj.password
    });
    return (userExist.length==1)?true:false;
    
}

var whitelist = ['http://24c83ddf.ngrok.io', 'http://example2.com']
var corsOptions = {
  origin: function (origin, callback) {
    if (whitelist.indexOf(origin) !== -1) {
      callback(null, true)
    } else {
      callback(new Error('Not allowed by CORS'))
    }
  }
}

//app.use(cors(corsOptions))

app.get('/products/:id',cors(corsOptions), function (req, res, next) {
    res.json({msg: 'This is CORS-enabled for all origins!'})
  })


  
app.get('/login', (req,res)=>{

    if(searchUser(req.query))
    {
        jwt.sign(req.query, 'privateKey',(err, token) =>{
            console.log(token);
            res.send(token)
        });  
    }
    else
    {
        res.send("User Not Found !!! Invalid Username or password")
    } 
})

app.get('/verify/:token',(req,res)=>{

    let token = req.params.token;
    let decoded =jwt.verify(token, 'privateKey');
    console.log('after decode '+ JSON.stringify(decoded))
    if(searchUser(decoded))
    {
        jwt.sign(decoded, 'privateKey',(err, token) =>{
            console.log(token);
            res.send("That was a Valid Token !!! Here is the new Token :  " + token)
        });  
    }
    else
    {
      res.send("Invalid Token !!!")  
    }
   
})

app.listen(3000)